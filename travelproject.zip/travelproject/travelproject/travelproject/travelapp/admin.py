from django.contrib import admin
from .models import Place
from .models import tips

admin.site.register(Place)
admin.site.register(tips)
# Register your models here.
