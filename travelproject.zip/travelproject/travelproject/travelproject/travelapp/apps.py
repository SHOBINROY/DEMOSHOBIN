from django.apps import AppConfig


class TravelappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'travelapp'
